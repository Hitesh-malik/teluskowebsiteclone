# Telusko
 Creating website for Telusko Website 
 install extension "Live Server"
 ![Screenshot 2024-10-14 160248](https://github.com/user-attachments/assets/c59e79d5-99fa-446f-b19c-ce15b88fd890)

after install click "go live" on right bottom side of vs code.


<img width="1242" alt="Screenshot 2024-10-14 160329" src="https://github.com/user-attachments/assets/1dbbb0d0-8710-4a3a-98a0-fab3601a986f">
